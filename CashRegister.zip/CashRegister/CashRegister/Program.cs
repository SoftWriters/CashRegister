﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DueToChange
{
    class Program
    {
        static void Main(string[] args)
        {
           
            // IF FILE NOT FOUND APPLICATION WILL EXIT
            if (!System.IO.File.Exists("Data.txt")) { Console.WriteLine("File Not Found"); Console.ReadLine(); return; }

            // Read Txt File From The Same Path as EXE
            string[] Lines = System.IO.File.ReadAllText("Data.txt").Split('\n');
            foreach (var line in Lines)
            {
                try
                {
                    var val = line.Split(',');
                    Console.WriteLine(line);
                    // CALL THE FUNCTIONS TO GENERATE THE CHANGE AMT
                    Console.WriteLine(new Change().ChangeReturn(Convert.ToDecimal(val[0]), Convert.ToDecimal(val[1])));
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                
            }
            Console.ReadLine();
        }
    }
    public class Change
    {
        decimal change = 0; bool multOfThree = false;
        int dollar = 0; int quarter = 0; int dime = 0; int nickel = 0; int cent = 0;

        // HOLDS THE COIN TYPES AND ITS VALUATIONS
        IDictionary<CoinType, decimal> CoinValues = new Dictionary<CoinType, decimal>();

        /// <summary>
        /// COINS TYPES
        /// </summary>
        enum CoinType
        {
            Dollar,
            Quarter,
            Dime,
            Nickel,
            Cent
        }

        public Change()
        {
            // CREATING THE LIST OF ALL COIN TYPES
            if (CoinValues.Count <= 0)
            {
                CoinValues.Add(CoinType.Dollar, 1);
                CoinValues.Add(CoinType.Quarter, 0.25M);
                CoinValues.Add(CoinType.Dime, 0.1M);
                CoinValues.Add(CoinType.Nickel, 0.05M);
                CoinValues.Add(CoinType.Cent, 0.01M);
            }

        }

        public string ChangeReturn(decimal owed, decimal paid)
        {
            change = paid - owed;

            // CASE WHEN OWED VALUE IS NOT MULTIPLE OF THREE
            if (owed % 3 != 0)
            {
                dollar = CoinCounts(CoinType.Dollar);
                quarter = CoinCounts(CoinType.Quarter);
                nickel = CoinCounts(CoinType.Nickel);
                dime = CoinCounts(CoinType.Dime);
                cent = CoinCounts(CoinType.Cent);
            }
            else
            {
                // CASE WHEN OWED VALUE IS A MULTIPLE OF THREE
                multOfThree = true;
                Random objrandom = new Random();
                
                while (change > 0)
                {
                    // Generate Random
                    var rand = objrandom.Next(1, 6);
                    
                    switch (rand)
                    {
                        case 1:
                            {
                                dollar = CoinCounts(CoinType.Dollar);
                                break;
                            }
                        case 2:
                            {
                                quarter = CoinCounts(CoinType.Quarter);
                                break;
                            }
                        case 3:
                            {
                                nickel = CoinCounts(CoinType.Nickel);
                                break;
                            }
                        case 4:
                            {
                                cent = CoinCounts(CoinType.Cent);
                                break;
                            }
                        case 5:
                            {
                                dime = CoinCounts(CoinType.Dime);
                                break;
                            }
                        default:
                            break;
                    }
                }
            }
            
            // FORMAT THE OUTPUT
            List<string> msgs = new List<string>();
            if (dollar > 0)
                msgs.Add(dollar.ToString() + " Dollar(s)");
            if (quarter > 0)
                msgs.Add(quarter.ToString() + " Quarter(s)");
            if (nickel > 0)
                msgs.Add(nickel.ToString() + " Nickel(s)");
            if (dime > 0)
                msgs.Add(dime.ToString() + " Dime(s)");
            if (cent > 0)
                msgs.Add(cent.ToString() + " Cent(s)");

            return string.Join(", ", msgs);
        }


        /// <summary>
        /// CALCULATES THE COIN TO DELIVER AS PER SELECTION
        /// </summary>
        /// <param name="cType">COIN TYPE</param>
        /// <returns></returns>

        private int CoinCounts(CoinType cType)
        {

            int retCoin = 0;
            // GET THE COIN VALUES AS PER SELECTION
            decimal CoinValuation = CoinValues[cType];
            if (multOfThree)
            {
                while (change >= CoinValuation)
                {
                    retCoin++;
                    change = change - CoinValuation;
                }
            }
            else
            {
                retCoin = Convert.ToInt32((change - change % CoinValuation) / CoinValuation);
                change = change - (retCoin * CoinValuation);
            }
            return retCoin;
        }

    }

}
